######################################################################################################
#Cargar librerias
######################################################################################################
library(tidyverse)
library(data.table)
library(stringi)
library(dummies)
library(randomForest)
library(caret)
library(nnet)
library(devtools)
library(rpart)
library(e1071)
library(ROCR)
library(igraph)

read_table_file <- function(path,...)
{
  output<-fread(path,...)
  setattr(output,"class",c("custom.data.table","data.table","data.frame"))
  return(output)
}

dots_to_list<-function(...)
{
  dots<-list(...)
  output<-c()
  if(length(dots))
  {
    for( i in 1:length(dots))
    {
      for( j in 1:length( dots[[i]] ) )
      {
        output[length(output)+1]<-dots[[i]][j]
      }
    }
  }
  output
}

select_columns <- function(dataframe,columns)
{
  dataframe[,..columns]
}

filter_rows<-function(dataframe,condition)
{
  icondition<-substitute(condition)
  icondition<-parseCondition( icondition )
  dataframe[eval(icondition)]
}

filter.custom.data.table<-function(.dataframe,...) 
{
  icondition<-substitute(...)
  icondition<-parseCondition( icondition )
  .dataframe[eval(icondition)]
}

distinct.custom.data.table<-function(.dataframe,...) 
{
  columns<-dots_to_list(...)
  if(is.null(columns))
  {
    temp=.dataframe
  }
  else
  {
    temp=select_columns(.dataframe,columns)
  }
  unique(temp)
}

select.custom.data.table<-function(.dataframe,...) 
{
  columns=dots_to_list(...)
  if(is.null(columns))
  {
    stop("Select must have a list of columns")
  }
  temp=select_columns(.dataframe,columns)
  unique(temp)
}

join<-function(.dataframe,other,by=NULL,mode="inner")
{
  output=NULL
  if(mode=="inner")
  {
    output=inner_join(.dataframe,other,by=by)
  }
  else if(mode=="left")
  {
    output=left_join(.dataframe,other,by=by)
  }
  else if(mode=="right")
  {
    output=right_join(.dataframe,other,by=by)
  }
  else if(mode=="full")
  {
    output=full_join(.dataframe,other,by=by)
  }
  else
  {
    stop("No implemented such mode")
  }
  setattr(output,"class",c("custom.data.table","data.table","data.frame"))
  (output)
}

union.custom.data.table<-function(.dataframe,other)
{
  setattr(.dataframe,"class",c("data.table","data.frame"))
  output=rbind(.dataframe,other)
  setattr(.dataframe,"class",c("custom.data.table","data.table","data.frame"))
  setattr(output,"class",c("custom.data.table","data.table","data.frame"))
  (output)
}

group_by.custom.data.table<-function(dataframe,...){
  setattr(.dataframe,"class",c("data.table","data.frame"))
  return(dataframe %>% group_by(...))
}

parseCondition<-function(onsub,isFirst=FALSE)
{
  if( !is.call(onsub) )
  {
    if(isFirst && exists(as.character(onsub)) )
    {
      return(as.name(eval(onsub)))
    }
    else
    {
      return(onsub)
    }
  }
  else
  {
    len=length( onsub )
    if(len==2)
    {
      p1<-parseCondition( onsub[[2]] , TRUE )
      if(onsub[[1]]=="eval")
      {
        return(p1)
      }
      else
      {
        return(as.call(c(onsub[[1]],p1)))
      }
    }
    else if(len==3)
    {
      p1<-parseCondition( onsub[[2]] , TRUE )
      p2<-parseCondition( onsub[[3]] , FALSE )
      return(as.call(c(onsub[[1]],p1,p2)))
    }
    else
    {
      stop("Error parsing comparison")
    }
  }
}

summary_table<-function(dataframe,...){
  # Disabling warnings
  old_warn <- getOption("warn")
  options(warn = -1)
  output<-dataframe %>% summarise(...)
  options(warn = old_warn)
  return(output)
}


is_empty_string<-function(value){
  temp=is.na(value)
  return(value==""|temp)
}

clean_text<-function(value){
  if(!is.character(value)){
    return(value)
  }
  output<-str_trim(gsub("\\s+"," ",stri_replace_all_regex(value,"\r\n"," ")))
  return(output)
}

save_to_csv<-function(dataframe,path,column=NULL,...)
{
  if(is.null(column)){
    fwrite(dataframe,path,...)
  }
  else{
    fwrite(dataframe[,column],path,...)
  }
}

############################

read_ficha_nacional<-function(...){
  output<-read_table_file("../data/1FN/ficha_nacional.csv",
                          select = c("nom_comercial","cod_act_princ", "act_principal","ruc","razon_social","comercio_ext",
                                     "facturacion","condicion","estado","tipo_emp","tamano","cond_domicilio","ubigeo",
                                     "act_secun1","act_secun2"),colClasses=list(character=1:6),...)
  return(output)
}

read_ciuu<-function(...){
  output<-read_table_file("../data/1FN/MaestroCIIU V4.0.csv",
                select = c("cod_act_princ","CATEGO_OBJETIVO","Actividad_Economica"),
                colClasses = list(character=1:3),...)
  return(output)
}

read_ruc_seleccionado<-function(...){
  output<-read_table_file("../data/1FN/RUC_GOV_CONSOLIDADO.csv",
                select = c("ruc","CATEGO_OBJETIVO","Actividad_Economica"),
                colClasses = list(character=1:3),...)
  return(output)
}

read_ruc_segmento<-function(...){
  output<-read_table_file("../data/3RUCSEGMENTO/ruc_segmentos.csv",colClasses = list(character=1:2),...)
  return(output)
}

read_cpe<-function(...){
  output<-read_table_file("../data/2CPE/FACT_2017_CAB.csv",
                select = c("COD_TIPOCOMP","NUM_RUC","NUM_SERIECPE","NUM_CPE",
                           "NUM_DOCIDENTI","MTO_IMPCPE","MTO_IGVCPE","FEC_EMICPE"),
                colClasses=list(character=1:6),quote="",...)
  return(output)
}

read_riesgo_target<-function(...){
  output<-read_table_file("../data/2CPE/Riesgo_123.csv",colClasses = list(character=1:6),....)
  return(output)
}

tree_func <- function(final_model, 
                      tree_num) {
  
  # get tree by index
  tree <- randomForest::getTree(final_model, 
                                k = tree_num, 
                                labelVar = TRUE) %>%
    tibble::rownames_to_column() %>%
    # make leaf split points to NA, so the 0s won't get plotted
    mutate(`split point` = ifelse(is.na(prediction), `split point`, NA))
  
  # prepare data frame for graph
  graph_frame <- data.frame(from = rep(tree$rowname, 2),
                            to = c(tree$`left daughter`, tree$`right daughter`))
  
  # convert to graph and delete the last node that we don't want to plot
  graph <- graph_from_data_frame(graph_frame) %>%
    delete_vertices("0")
  
  # set node labels
  V(graph)$node_label <- gsub("_", " ", as.character(tree$`split var`))
  V(graph)$leaf_label <- as.character(tree$prediction)
  V(graph)$split <- as.character(round(tree$`split point`, digits = 2))
  
  # plot
  plot <- ggraph(graph, 'dendrogram') + 
    theme_bw() +
    geom_edge_link() +
    geom_node_point() +
    geom_node_text(aes(label = node_label), na.rm = TRUE, repel = TRUE) +
    geom_node_label(aes(label = split), vjust = 2.5, na.rm = TRUE, fill = "white") +
    geom_node_label(aes(label = leaf_label, fill = leaf_label), na.rm = TRUE, 
                    repel = TRUE, colour = "white", fontface = "bold", show.legend = FALSE) +
    theme(panel.grid.minor = element_blank(),
          panel.grid.major = element_blank(),
          panel.background = element_blank(),
          plot.background = element_rect(fill = "white"),
          panel.border = element_blank(),
          axis.line = element_blank(),
          axis.text.x = element_blank(),
          axis.text.y = element_blank(),
          axis.ticks = element_blank(),
          axis.title.x = element_blank(),
          axis.title.y = element_blank(),
          plot.title = element_text(size = 18))
  
  (plot)
}

preprocessing_ficha_nacional<-function(ficha_nacional){
  flag<-is_empty_string(ficha_nacional$act_secun1)
  ficha_nacional$cant_act_1[flag] <- 0
  ficha_nacional$cant_act_1[!flag] <- 1
  
  flag<-is_empty_string(ficha_nacional$act_secun2)
  ficha_nacional$cant_act_2[flag] <- 0
  ficha_nacional$cant_act_2[!flag] <- 1
  
  ficha_nacional$cant_act <- 1 + as.numeric(ficha_nacional$cant_act_1) + as.numeric(ficha_nacional$cant_act_2)
  ficha_nacional$act_principal <- clean_text(ficha_nacional$act_principal)
  
  return(ficha_nacional)
}

preprocessing_cpe_ruc<-function(cpe_ruc){
  #Limpieza de espacios
  cpe_ruc$NUM_RUC <- clean_text(CPE_RUC$NUM_RUC)
  cpe_ruc$NUM_DOCIDENTI <- clean_text(CPE_RUC$NUM_DOCIDENTI)
  ###### FILTER IMPLEMENTATION MISSING ########
  cpe_ruc <- cpe_ruc %>% filter(nchar(NUM_DOCIDENTI)==11 & (stri_sub(NUM_DOCIDENTI,1,1)==1 |stri_sub(NUM_DOCIDENTI,1,1)==2))
  #############
  return(cpe_ruc)
}

preprocessing_md_factura<-function(md_factura){
  md_factura$FEC_EMICPE <- strptime(md_factura$FEC_EMICPE, "%Y-%m-%d %H:%M:%S")
  md_factura$dia_semana <- format(md_factura$FEC_EMICPE,"%A")
  md_factura$dia_mes <- format(md_factura$FEC_EMICPE,"%e")
  md_factura$FEC_EMICPE <- as.character(md_factura$FEC_EMICPE)
  
  #Agrupacion de montos
  md_factura$MTO_IMPCPE <- as.numeric(md_factura$MTO_IMPCPE)
  md_factura$MTO_IGVCPE <- as.numeric(md_factura$MTO_IGVCPE)
  
  return(md_factura)
}

preprocessing_md_factura_2<-function(md_factura){
  md_factura$tipo_emp.x_new <- NA
  md_factura$tipo_emp.x_new[md_factura$tipo_emp=="SOC.COM.RESPONS. LTDA"] <- "EMI_S/E.RLTDA"
  md_factura$tipo_emp.x_new[md_factura$tipo_emp=="EMPRESA INDIVIDUAL DE RESP. LTDA"] <- "EMI_S/E.RLTDA"
  md_factura$tipo_emp.x_new[md_factura$tipo_emp=="SOCIEDAD ANONIMA"] <- "EMI_SOCIEDAD ANONIMA"
  md_factura$tipo_emp.x_new[md_factura$tipo_emp=="SOCIEDAD ANONIMA CERRADA"] <- "EMI_SOCIEDAD ANONIMA CERRADA"
  md_factura$tipo_emp.x_new[md_factura$tipo_emp=="PERSONA NATURAL CON NEGOCIO"] <- "EMI_PERSONA NATURAL CON NEGOCIO"
  md_factura$tipo_emp.x_new[is.na(md_factura$tipo_emp.x_new)] <- "EMI_OTROS TIPO EMPRESA"
  md_factura$tipo_emp.x_new[md_factura$tipo_emp.x_new==" "] <- "EMI_OTROS TIPO EMPRESA"
  
  md_factura$dia_mes <- as.numeric(md_factura$dia_mes)
  md_factura$dia_mes_cat[md_factura$dia_mes<=3] <- "FEC_EMICPE.Inicio_mes[1-3]" #Al momento de emitir una factura, tienes hasta 3 dias con anterioridad para su emision
  md_factura$dia_mes_cat[md_factura$dia_mes>=25] <- "FEC_EMICPE.Fin_mes[25-31]" #En la ultima semana tratan de igual los ingresos para disminuir su IGV
  md_factura$dia_mes_cat[is.na(md_factura$dia_mes_cat)] <- "FEC_EMICPE.Otros[4-24]"
  
  md_factura$cut3_Monto<-cut(md_factura$MTO_IMPCPE,breaks = c(0,50,100,150,200,400,600,700,800,900,1000,max(md_factura$MTO_IMPCPE)))
  
  return(md_factura)
}

get_matriz_receptores<-function(md_factura,ficha_nacional,ruc_segmento){
  
  md_receptores <- md_factura %>% group_by(NUM_DOCIDENTI) %>% summarise()
  md_receptores <- left_join(md_receptores,ficha_nacional,by = c("NUM_DOCIDENTI"="ruc"))
  md_receptores <- left_join(md_receptores,ruc_segmento,by = c("NUM_DOCIDENTI"="ruc_segmentos.ruc"))
  
  rm(ficha_nacional,ruc_segmento)
  
  c01 <- dcast(md_factura,NUM_DOCIDENTI~ruc_segmentos.nom_segfisca,fun=mean,fill=0,value.var ="MTO_IMPCPE")#Segmento RUC
  c02 <- dcast(md_factura,NUM_DOCIDENTI~cod_act_princ,fun=mean,fill=0,value.var ="MTO_IMPCPE")#Actividad Económica Emisor
  c03 <- dcast(md_factura,NUM_DOCIDENTI~dia_semana, fun=mean,fill=0,value.var ="MTO_IMPCPE")#Dia de semana 
  c04 <- dcast(md_factura,NUM_DOCIDENTI~dia_mes_cat, fun=mean,fill=0,value.var ="MTO_IMPCPE")#Categoria dia de mes
  c05 <- dcast(md_factura,NUM_DOCIDENTI~Departamento_similar, fun=mean,fill=0,value.var ="MTO_IMPCPE")#Departamento similar
  c06 <- dcast(md_factura,NUM_DOCIDENTI~cut3_Monto, fun=length,fill=0,value.var ="MTO_IMPCPE")#Categoria monto
  c07 <- data.table(md_factura %>% group_by(NUM_DOCIDENTI) %>% summarise(Fac_compra = n()))
  c08 <- data.table(md_factura %>% group_by(NUM_DOCIDENTI) %>% summarise(Precio_Venta = sum(MTO_IMPCPE),IGV_Registrado = sum(MTO_IGVCPE)))
  c09 <- md_factura %>% group_by(NUM_DOCIDENTI,NewTarget) %>% summarise(n = n()) %>% spread(NewTarget,n) 
  c10 <- dcast(md_factura,NUM_DOCIDENTI~Actividad_Economica, fun=mean,fill=0,value.var ="MTO_IMPCPE")#Categoria monto
  
  
  c09 <- data.frame(c09 %>% replace_na(list(RT0 = 0,RT1 = 0, RT2 = 0, RT3 = 0)))
  c09$NewTarget <- (0 + c09$RT1 + 2*(c09$RT2) + 3*(c09$RT3))/((c09$RT1) + (c09$RT2) + (c09$RT3))
  c09$NewTarget_Cat[c09$NewTarget==3] <- "si"
  c09$NewTarget_Cat[is.na(c09$NewTarget_Cat)] <- "no"
  c09$NewTarget_Cat <- as.factor(c09$NewTarget_Cat)
  
  
  # NULL are the list-col equivalent of NAs
  md_receptores<-left_join(md_receptores, c01, by=c("NUM_DOCIDENTI"))
  md_receptores<-left_join(md_receptores, c02, by=c("NUM_DOCIDENTI"))
  md_receptores<-left_join(md_receptores, c03, by=c("NUM_DOCIDENTI"))
  md_receptores<-left_join(md_receptores, c04, by=c("NUM_DOCIDENTI"))
  md_receptores<-left_join(md_receptores, c05, by=c("NUM_DOCIDENTI"))
  md_receptores<-left_join(md_receptores, c06, by=c("NUM_DOCIDENTI"))
  md_receptores<-left_join(md_receptores, c07, by=c("NUM_DOCIDENTI"))
  md_receptores<-left_join(md_receptores, c08, by=c("NUM_DOCIDENTI"))
  md_receptores<-left_join(md_receptores, c09, by=c("NUM_DOCIDENTI"))
  md_receptores<-left_join(md_receptores, c10, by=c("NUM_DOCIDENTI"))
  rm(c01,c02,c03,c04,c05,c06,c07,c08,c09)
  return(md_receptores)
}

modification_matriz_receptores<-function(md_receptores){
  md_final <- md_receptores %>% select(NUM_DOCIDENTI,cod_act_princ,comercio_ext,facturacion,cond_domicilio,ubigeo,ruc_segmentos.nom_segfisca,`GRAN MEDIANO`,GRANDE,MEDIANO,MICRO,`PEQUEÃ‘O`,`55104`,`55205`,`63040`,`85111`,`85124`,`85193`,`92123`,`92149`,`92192`,`92413`,`92495`,domingo,jueves,lunes,martes,`miércoles`,`sábado`,viernes,`FEC_EMICPE.Fin_mes[25-31]`,`FEC_EMICPE.Inicio_mes[1-3]`,`FEC_EMICPE.Otros[4-24]`,`Diferente Departamento`,`Igual Departamento`,`(0,50]`,`(50,100]`,`(100,150]`,`(150,200]`,`(200,400]`,`(400,600]`,`(600,700]`,`(700,800]`,`(800,900]`,`(900,1e+03]`,`(1e+03,1.85e+07]`,Fac_compra,Precio_Venta,IGV_Registrado,cant_act,NewTarget_Cat,MODA,ENTRETENIMIENTO)
  
  names(md_final) <- c("RUC","C_ACT_PRINC","C_COMERCIO_EXT","C_TIPO_FACTURACION","C_CONDICION_DOMICILIO","C_UBIGEO","C_SEGMENTO_RUC","M_SE_GRANMEDIANO","M_SE_GRANDE","M_SE_MEDIANO","M_SE_MICRO","M_SE_PEQUENO","M_AE_HOTELES","M_AE_VIAJES","M_AE_RESTAURANTES","M_AE_HOSPITALES","M_AE_MEDICOS","M_AE_SALUDHUMANA","M_AE_FILMESVIDEOS","M_AE_TEATRO","M_AE_ENTRETENIMIENTO","M_AE_DEPORTIVO","M_AE_ESPARCIMIENTO","M_DSE_DOMINGO","M_DSE_JUEVES","M_DSE_LUNES","M_DSE_MARTES","M_DSE_MIERCOLES","M_DSE_SABADO","M_DSE_VIERNES","M_DME_2531","M_DME_0103","M_DME_0424","M_DEP_DIFERENTES","M_DEP_IGUALES","F_000_050","F_050_100","F_100_150","F_150_200","F_200_400","F_400_600","F_600_700","F_700_800","F_800_900","F_900_1000","F_1000_INF","F_FACTURAS","M_PRECIOVENTA","M_IGVREGISTRADO","F_ACT_ECON_REGISTRADO","NewTarget_Cat","MODA","ENTRETENIMIENTO")
  
  md_final$C_UBIGEO <- stri_sub(md_final$C_UBIGEO,1,2)
  md_final$C_UBIGEO <- as.factor(md_final$C_UBIGEO)
  
  md_final$C_ACT_PRINC <- stri_sub(md_final$C_ACT_PRINC,1,2)
  md_final$C_ACT_PRINC <- as.factor(md_final$C_ACT_PRINC)
  
  
  md_final$A1[md_final$M_AE_HOTELES>0]=1
  md_final$A2[md_final$M_AE_VIAJES>0]=1
  md_final$A3[md_final$M_AE_RESTAURANTES>0]=1
  md_final$A4[md_final$M_AE_HOSPITALES>0]=1
  md_final$A5[md_final$M_AE_MEDICOS>0]=1
  md_final$A6[md_final$M_AE_SALUDHUMANA>0]=1
  md_final$A7[md_final$M_AE_FILMESVIDEOS>0]=1
  md_final$A8[md_final$M_AE_TEATRO>0]=1
  md_final$A9[md_final$M_AE_ENTRETENIMIENTO>0]=1
  md_final$A10[md_final$M_AE_DEPORTIVO>0]=1
  md_final$A11[md_final$M_AE_ESPARCIMIENTO>0]=1
  md_final$A12[md_final$MODA>0]=1
  md_final$A13[md_final$ENTRETENIMIENTO>0]=1
  
  md_final$A1[is.na(md_final$A1)]=0
  md_final$A2[is.na(md_final$A2)]=0
  md_final$A3[is.na(md_final$A3)]=0
  md_final$A4[is.na(md_final$A4)]=0
  md_final$A5[is.na(md_final$A5)]=0
  md_final$A6[is.na(md_final$A6)]=0
  md_final$A7[is.na(md_final$A7)]=0
  md_final$A8[is.na(md_final$A8)]=0
  md_final$A9[is.na(md_final$A9)]=0
  md_final$A10[is.na(md_final$A10)]=0
  md_final$A11[is.na(md_final$A11)]=0
  md_final$A12[is.na(md_final$A12)]=0
  md_final$A13[is.na(md_final$A13)]=0
  md_final$R_COMBINADO_AE <- apply(md_final[,54:66],1,sum)
  return(md_final)
}

get_data_final<-function(md_final,trabajadores,palabras_raras,frecuencia_igv,igv_octubre){
  
  md_final <- left_join(md_final,palabras_raras,by=c("RUC"="ruc"))
  md_final <- left_join(md_final,Frecuencia_IGV,by=c("RUC"="n_doc_declado"))
  md_final <- left_join(md_final,igv_octubre,by=c("RUC"="n_doc_declado"))
  md_final <- left_join(md_final,trabajadores,by=c("RUC"="f601_2017.n_doc_declado"))
  names(md_final)
  
  md_final$PropDif[is.na(md_final$PropDif)] <- 0
  md_final$Frec_IGV[is.na(md_final$Frec_IGV)] <- 0
  md_final$Rest[is.na(md_final$Rest)] <- 0
  md_final$Prom_trabajadores[is.na(md_final$Prom_trabajadores)] <- 0
  md_final$Prom_Prestad_Servicio[is.na(md_final$Prom_Prestad_Servicio)] <- 0
  
  names(Test.md_final)
  
  md_final$C_COMERCIO_EXT[is.na(md_final$C_COMERCIO_EXT)] <- "BLANCO"
  md_final$C_TIPO_FACTURACION[is.na(md_final$C_TIPO_FACTURACION)] <- "BLANCO"
  md_final$C_CONDICION_DOMICILIO[is.na(md_final$C_CONDICION_DOMICILIO)] <- "BLANCO"
  md_final$C_SEGMENTO_RUC[is.na(md_final$C_SEGMENTO_RUC)] <- "BLANCO"
  md_final$F_ACT_ECON_REGISTRADO[is.na(md_final$F_ACT_ECON_REGISTRADO)] <- 0
  
  return(md_final)
}

split_data_train_test<-function(md_final,trainname="train.md_final",test_name="test.md_final"){
  ######################################################################################################
  #Creacion d edatos de entrenamiento y 
  ######################################################################################################
  Tn <- sum(md_final$NewTarget_Cat=="no")
  Ts <- sum(md_final$NewTarget_Cat=="si")
  
  set.seed(216)
  indexes <-  sample(1:Tn, size=(Ts*0.7/0.3))
  
  Test.md_final <- filter(md_final,NewTarget_Cat=="no")[-indexes,]
  Train.md_final <- filter(md_final,NewTarget_Cat=="no")[indexes,]
  
  Train.md_final %>% group_by(NewTarget_Cat) %>% summarise(n())
  
  Train.md_final <- bind_rows(Train.md_final,data.frame(filter(md_final,NewTarget_Cat=="si")))
  
  names(Test.md_final)
  ######################################################################################################
  #Creacion d edatos de entrenamiento y 
  ######################################################################################################
  Varibles_modelo <- c("C_COMERCIO_EXT","C_TIPO_FACTURACION","C_CONDICION_DOMICILIO","C_UBIGEO","C_SEGMENTO_RUC","M_SE_GRANMEDIANO","M_SE_GRANDE","M_SE_MEDIANO","M_SE_MICRO" ,"M_SE_PEQUENO","M_AE_HOTELES","M_AE_VIAJES","M_AE_RESTAURANTES","M_AE_HOSPITALES","M_AE_MEDICOS", "M_AE_SALUDHUMANA","M_AE_FILMESVIDEOS","M_AE_TEATRO","M_AE_ENTRETENIMIENTO","M_AE_DEPORTIVO","M_AE_ESPARCIMIENTO","MODA","ENTRETENIMIENTO","M_DSE_DOMINGO","M_DSE_JUEVES","M_DSE_LUNES","M_DSE_MARTES","M_DSE_MIERCOLES","M_DSE_SABADO","M_DSE_VIERNES","M_DME_2531","M_DME_0103","M_DME_0424","M_DEP_DIFERENTES","M_DEP_IGUALES","F_000_050","F_050_100","F_100_150","F_150_200","F_200_400","F_400_600","F_600_700","F_700_800","F_800_900","F_900_1000","F_1000_INF","F_FACTURAS","M_PRECIOVENTA","M_IGVREGISTRADO","F_ACT_ECON_REGISTRADO","R_COMBINADO_AE","NewTarget_Cat","PropDif","Frec_IGV","Rest","Prom_Trabajadores","Prom_Prestad_Servicio")
  
  Train.md_final <- Train.md_final[,Varibles_modelo]
  Test.md_final <- Test.md_final[,c("RUC",Varibles_modelo)]
  
  
  ######################################################################################################
  #Modelo RF
  ######################################################################################################
  Train.md_final$C_COMERCIO_EXT <- factor(Train.md_final$C_COMERCIO_EXT)
  Train.md_final$C_TIPO_FACTURACION <- factor(Train.md_final$C_TIPO_FACTURACION)
  Train.md_final$C_CONDICION_DOMICILIO <- factor(Train.md_final$C_CONDICION_DOMICILIO)
  Train.md_final$C_SEGMENTO_RUC <- factor(Train.md_final$C_SEGMENTO_RUC)
  levels(Train.md_final$C_COMERCIO_EXT)[levels(Train.md_final$C_COMERCIO_EXT)==""] <- "BLANCO"
  levels(Train.md_final$C_TIPO_FACTURACION)[levels(Train.md_final$C_TIPO_FACTURACION)==""] <- "BLANCO"
  levels(Train.md_final$C_CONDICION_DOMICILIO)[levels(Train.md_final$C_CONDICION_DOMICILIO)==" "] <- "BLANCO"
  assign(train_name,Train.md_final , pos=1)
  assign(test_name, Test.md_final, pos=1)
}

write_results<-function(model,test_set){
  
  plot(model,ylim=c(0,1))
  legend('topright',colnames(model$err.rate),col = 1:3,fill = 1:3)
  
  importancia <- importance(model)
  varImportancia <- data.frame(Variables = row.names(importancia),
                               Importancia = round(importancia[,'MeanDecreaseGini'],2))
  
  rankImportancia <- varImportancia %>% mutate(Rank = paste0('#',dense_rank(desc(Importancia))))
  
  ggplot(rankImportancia,aes(x=reorder(Variables,Importancia),y=Importancia, fill=Importancia))+
    geom_bar(stat = "identity")+
    geom_text(aes(x=Variables,y=0.5,label=Rank),hjust=0,vjust=0.55,size=4,colour = "white")+
    labs(x="Variables")+
    coord_flip()
  
  pred1 <- predict(model,test_set)
  pred1p <- predict(model,test_set,type = "prob")[,2]
  
  test_set$pred1 <- pred1
  test_set$pred1p <- pred1p
  
  test_set %>% group_by(pred1) %>% summarise(n())
  Resultados_Test<- filter(test_set, pred1=="si")
  
  write.csv(Resultados_Test,"Resultados_Test",row.names = F)
  r2pmml(model,"../results/model_output.pmml")
}

identidad<-function(value){
  value
  return(value)
}


preprocessing_ficha_nacional_2<-function(ficha_nacional){
  flag<-is_empty_string(ficha_nacional$act_secun1)
  ficha_nacional$cant_act_1[flag] <- 0
  ficha_nacional$cant_act_1[!flag] <- 1
  return(ficha_nacional)
}
